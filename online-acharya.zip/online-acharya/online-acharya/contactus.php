<!DOCTYPE html>
<html lang="">
<head>
<title>Online Acharya</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link href="layout/styles/style.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="bgded " style="background-image:url('images/about-bg.jph");"> 

  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 

      <div id="logo" class="fl_left">
        <h1><a href="index.html">Online Acharya</a></h1>
      </div>
      <nav id="mainav" class="fl_right">
        <ul class="clear">
          <li ><a href="indexmain.html">Home</a></li>
          <li ><a href="services.html">Services</a></li>
          <li ><a href="aboutus.html">About Us</a></li>
          <li class="active" ><a href="contact.php">Contact Us</a></li>
          <li ><a href="#"></a></li>

      </nav>
      
    </header>
  </div>
  <div id="breadcrumb" class="bgded"   style="background-image:url('images/about-bg.jpg"> 


  </div>

  <div class="background">
    <div class="container">
      <div class="screen">
        <div class="screen-header">
          <div class="screen-header-left">
            <div class="screen-header-button close"></div>
            <div class="screen-header-button maximize"></div>
            <div class="screen-header-button minimize"></div>
          </div>
          <div class="screen-header-right">
            <div class="screen-header-ellipsis"></div>
            <div class="screen-header-ellipsis"></div>
            <div class="screen-header-ellipsis"></div>
          </div>
        </div>
        <div class="screen-body">
          <div class="screen-body-item left">
            <div class="app-title">
              <span>CONTACT</span>
              <span>US</span>
            </div>
            <div class="app-contact">CONTACT INFO : +62 81 314 928 595</div>
          </div>
          <div class="screen-body-item">
          <form action="contactdata.php" method="post">
            <div class="app-form">
              <div class="app-form-group">
                <input class="app-form-control" name="name" placeholder="NAME" >
              </div>
              <div class="app-form-group">
                <input class="app-form-control" name="email" placeholder="EMAIL">
              </div>


              <div class="app-form-group message">
                <input class="app-form-control" name="message" placeholder="MESSAGE">
              </div>
              <div class="app-form-group buttons">
                <button class="app-form-button" type="submit">SEND</button>
              </div>
            </div>
          </form>
          </div>
        </div>
      </div>
      
    </div>
  </div>

  <div class="wrapper row4">
    <footer id="footer" class="hoc clear"> 
  
      <div class="one_quarter first">
        <h6 class="heading"><Ri:a>Reach us</Ri:a></h6>
        <ul class="nospace btmspace-30 linklist contact">
          <li><i class="fa fa-map-marker"></i>
            <address>
            Rajouri Garden &amp; New delhi 11027
            </address>
          </li>
          <li><i class="fa fa-phone"></i> +91 123 456 456</li>
          <li><i class="fa fa-envelope-o"></i> cfs@gmail.com</li>
        </ul>
      </div>
      <div class="one_quarter">
        <h6 class="heading">Scholastic Programs</h6>
        <ul class="nospace linklist">
        <li><a href="maths.html">Mental Math</a></li>
          <li><a href="english.html">Learning English</a></li>
          <li><a href="science.html">LabonLaptop (Science)</a></li>
        </ul>
      </div>
      <div class="one_quarter">
        <h6 class="heading">Co-Scholastic Programs</h6>
        <ul class="nospace linklist">
          <li><a href="dance.html">Dance On top</a></li>
          <li><a href="cook.html">Just Cook it</a></li>
          <li><a href="code.html">Codenator</a></li>
        </ul>
      </div>
      <div class="one_quarter">
        <h6 class="heading">About Our Services</h6>
        <p class="nospace btmspace-15">A personalized learning resource for all ages -Academy/ school offers practice exercises, instructional videos, and a personalized learning dashboard that empower learners to study at their own pace in and outside of the classroom.</p>
      </div>
  
    </footer>
  </div>
  
  <div class="wrapper row5">
    <div id="copyright" class="hoc clear"> 
  
      <p class="fl_center">Copyright &copy; <a href="#">Online Acharya</a></p>
  
    </div>
  </div>
  
  <a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
  
  <script src="layout/scripts/jquery.backtotop.js"></script>
  <script src="layout/scripts/jquery.mobilemenu.js"></script>
  </body>
  </html>
  
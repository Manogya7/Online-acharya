<?php


session_start();
header('location:contactus.php');


$con = mysqli_connect('localhost','root', '123456');

mysqli_select_db($con, 'contactdata');

$name = $_POST['name'];
$pass = $_POST['email'];
$pass = $_POST['message'];

$s = " select * from usertable where name = '$name'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);


    $reg= " insert into usertable(name , email , message) values ('$name' , '$email' , $message)";
    mysqli_query($con, $reg);
    echo "Registration Successful";



?>
<?php

session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="">
<head>
<title>Online Acharya</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="bgded"> 

  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 

      <div id="logo" class="fl_left">
        <h1><a href="index.html">Online Acharya</a></h1>
      </div>
      <nav id="mainav" class="fl_right">
        <ul class="clear">
          <li class="active"><a href="index2.php">Home</a></li>
          <li ><a href="services.php">Services</a></li>
          <li ><a href="aboutus.php">About Us</a></li>
          <li ><a href="contactus.php">Contact Us</a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"><?php echo $_SESSION['username']; ?></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>

          <li ><a href="logout.php">Logout</a></li>


      </nav>
      
    </header>
  </div>
  <div id="breadcrumb" class="bgded"   style="background-image:url('images/about-bg.jpg"> 



  </div>
    <br><br><br>
       


 <center> <h1>Welcome <?php echo $_SESSION['username']; ?> </h1> </center>

<br><br><br>
<center><form action="upload.php" method="post" enctype="multipart/form-data">
    Select file to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload " name="submit">
</form></center>

  <div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 

    <div class="one_quarter first">
      <h6 class="heading"><Ri:a>Reach us</Ri:a></h6>
      <ul class="nospace btmspace-30 linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Rajouri Garden &amp; New delhi 11027
          </address>
        </li>
        <li><i class="fa fa-phone"></i> +91 123 456 456</li>
        <li><i class="fa fa-envelope-o"></i> cfs@gmail.com</li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Scholastic Programs</h6>
      <ul class="nospace linklist">
      <li><a href="maths.php">Mental Math</a></li>
          <li><a href="english.php">Learning English</a></li>
          <li><a href="science.php">LabonLaptop (Science)</a></li>
        </ul>
      </div>
      <div class="one_quarter">
        <h6 class="heading">Co-Scholastic Programs</h6>
        <ul class="nospace linklist">
          <li><a href="dance.php">Dance On top</a></li>
          <li><a href="cook.php">Just Cook it</a></li>
          <li><a href="code.php">Codenator</a></li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">About Our Services</h6>
      <p class="nospace btmspace-15">A personalized learning resource for all ages -Academy/ school offers practice exercises, instructional videos, and a personalized learning dashboard that empower learners to study at their own pace in and outside of the classroom.</p>
    </div>

  </footer>
</div>

<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 

    <p class="fl_center">Copyright &copy; <a href="#">Online Acharya</a></p>

  </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>

<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>
<?php

session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}

?>
<!DOCTYPE html>
<html lang="">
<head>
<title>Online Acharya</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="bgded overlay light" style="background-image:url('images/Learning.png');"> 

  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 

      <div id="logo" class="fl_left">
        <h1><a href="index.html">Scholastic Services</a></h1>
      </div>
      <nav id="mainav" class="fl_right">
        <ul class="clear">
        <li ><a href="index2.php">Home</a></li>
        <li class="active"><a href="services.php">Services</a></li>
          <li><a href="aboutus.php">About Us</a></li>
          <li ><a href="contactus.php">Contact Us</a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"><?php echo $_SESSION['username']; ?></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>

          <li ><a href="logout.php">Logout</a></li>
      </nav>
      
    </header>
    <div id="pageintro" class="bgded" style="background-image: url('images/bgschol.jpg');"> 

  
    </div>
  </div>
  <div class="wrapper row3">
    <main class="hoc container clear"> 

      <hr class="btmspace-80">

      <ul class="nospace group overview">
      <li class="one_third">
            <article><a href="#"><img src="images/maths.png" alt=""></a>
            <h6 class="heading">Mental Maths</h6>
            <ul class="nospace meta">

            </ul>
            <p>Mental math is an extremely common and practical skill, and most people do at least some mental math on a daily basis. Without the
              ability to do mental math, it can be difficult to complete ordinary daily tasks.&hellip;</p>
            <footer class="nospace"><a class="btn" href="maths.php">View&raquo;</a></footer>
          </article>
        </li>
        <li class="one_third">
            <article><a href="#"><img src="images/englishg.jpg" alt=""></a>
            <h6 class="heading">Learning English</h6>
            <ul class="nospace meta">

            </ul>
            <p>Don't be afraid of English grammar! With our free learning course and exercises, you'll find out how much fun and easy it is to use English once you understand the basics of English grammar!&hellip;</p>
            <footer class="nospace"><a class="btn" href="english.php">View &raquo;</a></footer>
          </article>
        </li>
        <li class="one_third">
          <article><a href="#"><img src="images/science.jpg" alt=""></a>
            <h6 class="heading">LabonLaptop (Science)</h6>
            <ul class="nospace meta">

            </ul>
            <p>What is virtual lab? Experience the answer here yourself. Our science software for kids, students and teachers are significant&hellip;</p>
            <footer class="nospace"><a class="btn" href="science.php">View &raquo;</a></footer>
          </article>
        
            
        
      </ul>

      <div class="clear"></div>
    </main>
  </div>

  <div class="wrapper bgded overlay coloured" style="background-image:url('images/logobd.jpg');">
    <article class="hoc cta clear"> 
  
    <h6 class="three_quarter first">Upload Your File Now!</h6>
      <footer class="one_quarter"><a class="btn" href="main.php">Upload &raquo;</a></footer>
  
    </article>
  </div>

  <div class="wrapper row4">
    <footer id="footer" class="hoc clear"> 
  
      <div class="one_quarter first">
        <h6 class="heading"><Ri:a>Reach us</Ri:a></h6>
        <ul class="nospace btmspace-30 linklist contact">
          <li><i class="fa fa-map-marker"></i>
            <address>
            Rajouri Garden &amp; New delhi 11027
            </address>
          </li>
          <li><i class="fa fa-phone"></i> +91 123 456 456</li>
          <li><i class="fa fa-envelope-o"></i> cfs@gmail.com</li>
        </ul>
      </div>
      <div class="one_quarter">
        <h6 class="heading">Scholastic Programs</h6>
        <ul class="nospace linklist">
          <li><a href="maths.php">Mental Math</a></li>
          <li><a href="english.php">Learning English</a></li>
          <li><a href="science.php">LabonLaptop (Science)</a></li>
        </ul>
      </div>
      <div class="one_quarter">
        <h6 class="heading">Co-Scholastic Programs</h6>
        <ul class="nospace linklist">
          <li><a href="dance.php">Dance On top</a></li>
          <li><a href="cook.php">Just Cook it</a></li>
          <li><a href="code.php">Codenator</a></li>
        </ul>
      </div>
      <div class="one_quarter">
        <h6 class="heading">About Our Services</h6>
        <p class="nospace btmspace-15">A personalized learning resource for all ages -Academy/ school offers practice exercises, instructional videos, and a personalized learning dashboard that empower learners to study at their own pace in and outside of the classroom.</p>
      </div>
  
    </footer>
  </div>
  
  <div class="wrapper row5">
    <div id="copyright" class="hoc clear"> 
  
      <p class="fl_center">Copyright &copy; <a href="#">Online Acharya</a></p>
  
    </div>
  </div>
  
  <a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
  
  <script src="layout/scripts/jquery.backtotop.js"></script>

  </body>
  </html>
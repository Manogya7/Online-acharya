<?php

session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="">
<head>
<title>Online Acharya</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="bgded " style="background-image:url('images/about-bg.jpg');"> 

  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 

      <div id="logo" class="fl_left">
        <h1><a href="index.html">Online Acharya</a></h1>
      </div>
      <nav id="mainav" class="fl_right">
        <ul class="clear">
        <li ><a href="index2.php">Home</a></li>
        <li class="active"><a href="services.php">Services</a></li>
          <li><a href="aboutus.php">About Us</a></li>
          <li ><a href="contactus.php">Contact Us</a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"><?php echo $_SESSION['username']; ?></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>

          <li ><a href="logout.php">Logout</a></li>

      </nav>
      
    </header>
  </div>
  <div id="breadcrumb" class="hoc clear"> 

    <ul>
      <li><a href="indexmain.html">Home</a></li>
      <li><a href="services.html">Services</a></li>
      <li><a href="scholastic.html">Scholastc Services</a></li>
      <li><a href="#">Maths</a></li>
    </ul>

  </div>

</div>
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <div class="content"> 
      <h1>Mental Maths - The best Maths Program</h1>
      <img class="imgr borderedbox inspace-5" src="images/maths.png" alt="">
      <p>Mental math is an extremely common and practical skill, and most people do at least some mental math on a daily basis. Without the<br>
        ability to do mental math, it can be difficult to complete ordinary daily tasks.<br>
        By Amanda Morin Fact checked by Cara Lustik Updated on May 12, 2020<br>
        Students who master the technique of mental math will find that it helps them in many situations, both in school and outside of the<br>
        classroom. They may use mental math to calculate how many video games they can buy with their weekly allowance or tally how<br>
        much the snacks they grabbed from the corner store will cost before they walk up to the register.<br>
        In their studies, knowing mental math methods can help make new concepts easier to learn. Having even basic mental math skills<br>
        means the student does not have to stop the process of problem-solving to use a calculator, which is very useful when taking tests or<br>
        completing homework assignments.<br>
        For teenagers and adults, mental math skills make it possible to calculate the price of sale items, know how big of a tip to leave, or<br>
        how to split a bill when a large party dines out.<br></p>
        
 <br><Br>

      <img class="imgl borderedbox inspace-5" src="images/maths2.png" alt="">
      <p>Certain students will be better at some forms of mental math than others. Some students may be able to easily add and subtract but
        <br>may face difficulty dividing and multiply mentally, especially when large numbers are involved.<br>
        <br>If your child struggles with all forms of mental math, it's important to discover the root of the problem. Does your child struggle in math
        <br>class, even when a pencil, paper, and calculator are handy? Or does your child only struggle when figuring out equations in his or her
        head?
        <br>Difficulty completing mental math problems may signal that your child hasn't mastered basic mathematical strategies. She may need
        <br>extra help or someone to teach such concepts to her in a different way.
        </p>
        <br>

      </div>
</main>
</div>
      <div class="wrapper bgded overlay coloured" style="background-image:url('images/logobd.jpg');">
        <article class="hoc cta clear"> 
      
        <h6 class="three_quarter first">Upload Your Data Now</h6>
    <footer class="one_quarter"><a class="btn" href="main.php">Upload&raquo;</a></footer>
      
        </article>
      </div>

  <div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 

    <div class="one_quarter first">
      <h6 class="heading"><Ri:a>Reach us</Ri:a></h6>
      <ul class="nospace btmspace-30 linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Rajouri Garden &amp; New delhi 11027
          </address>
        </li>
        <li><i class="fa fa-phone"></i> +91 123 456 456</li>
        <li><i class="fa fa-envelope-o"></i> cfs@gmail.com</li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Scholastic Programs</h6>
      <ul class="nospace linklist">
        <li><a href="maths.html">Mental Math</a></li>
        <li><a href="english.html">Learning English</a></li>
        <li><a href="science.html">LabonLaptop (Science)</a></li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Co-Scholastic Programs</h6>
      <ul class="nospace linklist">
        <li><a href="dance.html">Dance On top</a></li>
        <li><a href="cook.html">Just Cook it</a></li>
        <li><a href="code.html">Codenator</a></li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">About Our Services</h6>
      <p class="nospace btmspace-15">A personalized learning resource for all ages -Academy/ school offers practice exercises, instructional videos, and a personalized learning dashboard that empower learners to study at their own pace in and outside of the classroom.</p>
    </div>

  </footer>
</div>

<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 

    <p class="fl_center">Copyright &copy; <a href="#">Online Acharya</a></p>

  </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>

<script src="layout/scripts/jquery.backtotop.js"></script>

</body>
</html>
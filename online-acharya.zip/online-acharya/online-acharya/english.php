<?php

session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="">
<head>
<title>Online Acharya</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="bgded " style="background-image:url('images/about-bg.jpg');"> 

  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 

      <div id="logo" class="fl_left">
        <h1><a href="index.html">Online Acharya</a></h1>
      </div>
      <nav id="mainav" class="fl_right">
        <ul class="clear">
        <li ><a href="index2.php">Home</a></li>
        <li class="active"><a href="services.php">Services</a></li>
          <li><a href="aboutus.php">About Us</a></li>
          <li ><a href="contactus.php">Contact Us</a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"><?php echo $_SESSION['username']; ?></a></li>
          <li ><a href="#"></a></li>
          <li ><a href="#"></a></li>

          <li ><a href="logout.php">Logout</a></li>

      </nav>
      
    </header>
  </div>
  <div id="breadcrumb" class="hoc clear"> 

    <ul>
      <li><a href="indexmain.html">Home</a></li>
      <li><a href="services.html">Services</a></li>
      <li><a href="scholastic.html">Scholastc Services</a></li>
      <li><a href="#">English</a></li>
    </ul>

  </div>

</div>
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <div class="content"> 
      <h1>Learning English - The best english program</h1>
      <img class="imgr borderedbox inspace-5" src="images/englishg.jpg" alt="">
      <p>Don't be afraid of English grammar! With our free learning course and exercises, you'll find out how much fun and easy it is to use English once you understand the basics of English grammar!
 <br><Br>
        What can you find here?<br><br>
        entertaining units that help you learn the English tenses quickly<br>
        interactive grammar exercises that will help you practice and remember new rules and patterns<br>
        clear and simple explanations of parts of speech and sentence structures<br>
        Get started now and learn to understand and use English grammar!</p><br><br>
      <img class="imgl borderedbox inspace-5" src="images/englisht.jpg" alt="">
      <p>Tenses and Verb forms<br><br>
        Tenses and verbs cannot be separated, as tenses are mainly expressed by conjugating a verb.<br><br>
         
        This section has…<br>
        detailed explanations and rules for the use of tenses<br>
        an introduction to different important verbs and their irregularities<br>
        many entertaining exercises to help you practice<br>
        Get started now with one of the following categories and choose a specific learning unit by using the tabs at the top of the page!</a>.</p>
        <br><br>  <p>Tenses<br><br>
        Mastering verb tenses is very important if you want to be understood while speaking English. In this section, you will find understandable explanations of the many verb tenses, detailed examples, and several exercises to help you practice. Regardless of whether you want to learn the simple past or the will-future, this section covers all tenses of the past, present, and future!</a> section.</p>
        <br>

      </div>
</main>
</div>
      <div class="wrapper bgded overlay coloured" style="background-image:url('images/logobd.jpg');">
        <article class="hoc cta clear"> 
          
        <h6 class="three_quarter first">Upload Your Data Now</h6>
    <footer class="one_quarter"><a class="btn" href="main.php">Upload&raquo;</a></footer>
      
        </article>
      </div>

  <div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 

    <div class="one_quarter first">
      <h6 class="heading"><Ri:a>Reach us</Ri:a></h6>
      <ul class="nospace btmspace-30 linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Rajouri Garden &amp; New delhi 11027
          </address>
        </li>
        <li><i class="fa fa-phone"></i> +91 123 456 456</li>
        <li><i class="fa fa-envelope-o"></i> cfs@gmail.com</li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Scholastic Programs</h6>
      <ul class="nospace linklist">
        <li><a href="maths.html">Mental Math</a></li>
          <li><a href="english.html">Learning English</a></li>
          <li><a href="science.html">LabonLaptop (Science)</a></li>
        </ul>
      </div>
      <div class="one_quarter">
        <h6 class="heading">Co-Scholastic Programs</h6>
        <ul class="nospace linklist">
          <li><a href="dance.html">Dance On top</a></li>
          <li><a href="cook.html">Just Cook it</a></li>
          <li><a href="code.html">Codenator</a></li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">About Our Services</h6>
      <p class="nospace btmspace-15">A personalized learning resource for all ages -Academy/ school offers practice exercises, instructional videos, and a personalized learning dashboard that empower learners to study at their own pace in and outside of the classroom.</p>
    </div>

  </footer>
</div>

<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 

    <p class="fl_center">Copyright &copy; <a href="#">Online Acharya</a></p>

  </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>

<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>